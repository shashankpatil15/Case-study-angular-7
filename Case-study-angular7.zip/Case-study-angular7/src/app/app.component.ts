import { Component } from '@angular/core';

@Component({
  selector: 'app-root',//where to inject
  templateUrl: './app.component.html',//where to dipslay more than 3 lines
  //template: '<h1>{{title}}</h1>',//where to dipslay less than 4 lines
  
  styleUrls: ['./app.component.css']//how to display
})
export class AppComponent {
  title = 'Angular Course @ Softedge';// what to display
}

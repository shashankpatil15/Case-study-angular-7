import { Component, OnInit,OnDestroy } from '@angular/core';

@Component({
  selector: 'app-angular-basics',
  templateUrl: './angular-basics.component.html',
  styleUrls: ['./angular-basics.component.css']
})
export class AngularBasicsComponent implements OnInit,OnDestroy {

   title='Angular Basics';
   colors=['RED','GREEN','BLUE'];
   day=1;
   min=1;
   max=8;
   name={fname:'Pradeep',lname:'Chinchole'};
   show=true;
   hide=false;

  constructor() {
    console.log("AngularBasicsComponent created...");

   }

  ngOnInit() {
    console.log("AngularBasicsComponent initialized...");
    
  }
  
  ngOnDestroy() {
    console.log("AngularBasicsComponent destroyed...");
    
  }
  
  showHide(){
    this.hide=!this.hide;
  }

}

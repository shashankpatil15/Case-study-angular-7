import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'gender'
})
export class GenderPipe implements PipeTransform {
  constructor(){
    console.log("GenderPipe created...")
  }

  transform(value: number): string {
    console.log("GenderPipe tranform emethod......")
    switch(value)
    {
      case 1:return 'Male';
      case 2:return 'Female';
      case 3:return 'Not disclosed';
    }
  }

}
